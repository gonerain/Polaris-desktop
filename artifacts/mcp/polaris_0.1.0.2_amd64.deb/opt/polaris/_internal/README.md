# Polaris

Polaris v0.1.0.2 是基于 Python、PySide6 / Qt Quick 的本地组件工作台。正式入口使用 `next/polaris_platform`：桌宠打开画布，组件管理负责安装、启动、授权和撤销，业务能力由各组件提供。

## 能力与使用

- [MCP 接入](next/components/mcp/README.md)默认随桌面启动，为 Codex 提供组件目录、操作说明和公开操作调用。默认授予全部可调用公开能力的后台权限，手动撤销后不会补授。

- 默认鲸鱼娘皮肤复用现有透明动画，支持进入回应、按压、拖放和随机待机；右键打开组件管理或退出。工具窗不接受焦点，身体、气泡和菜单之外的透明区域可穿透输入，实际效果取决于窗口系统。
- 画布挂载组件自己的原生视图，支持移动、缩放、折叠和布局保存。隐藏或移除视图保留业务数据，停止组件才结束其能力。
- 微信、日程和 Agent Bridge 通过独立插件源安装；一个仓库可以提供多个插件。
- 公开能力按安装身份和具体操作授权；新增能力不自动授权，撤权约束已有视图和调用上下文。后台恢复不重新授予已撤销权限。

首次打开桌面时，组件管理会在后台从官方仓库安装并启动微信、日程和 Agent Bridge。已安装或已卸载的组件保留用户选择。网络失败可在“组件管理 → 插件源”中重试。默认地址见[组件管理配置](next/components/manager/default-sources.json)。

## 运行

Python 3.10+；在仓库根目录建立独立环境：

```bash
python -m venv .venv
# Linux / macOS
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python main.py
# Windows
.venv\Scripts\python.exe -m pip install -r requirements.txt
.venv\Scripts\python.exe main.py
```

`python main.py --version` 显示软件版本。`--headless` 打印所选组件状态后退出。`--config PATH` 选择装配，`--state-dir PATH` 指定平台安装与授权数据目录。开发者也可运行 `PYTHONPATH=next python -m polaris_platform --gui`；模块入口不加 `--gui` 时只启动、检查并停止所选组件。

平台安装、授权与自启动设置保存在平台数据目录；桌宠位置和画布布局保存在各自组件目录。[平台运行与数据目录](docs/platform-compatibility.md)。

## 打包

在目标操作系统自己的虚拟环境中执行：

```bash
python -m pip install pyinstaller
python -m PyInstaller --noconfirm Polaris.spec
```

输出为 `dist/Polaris/`；Windows 运行 `Polaris.exe`，Linux 运行 `Polaris`。分发时保留整个目录，不能只复制可执行文件。源码和包内默认皮肤均自带动画及许可，不依赖外部素材下载。Windows、macOS 的构建与真实桌面效果仍需分别验收，Linux 构建也不能代替其他系统构建。

### Debian / Ubuntu 安装包与更新

在 Ubuntu 22.04 或相同 glibc 基线的 Linux 环境中构建（架构与构建机一致）：

```bash
.venv/bin/python -m pip install pyinstaller==6.16.0
.venv/bin/python tools/build_deb.py
sudo apt install ./dist/polaris_0.1.0.2_amd64.deb
```

输出包含 deb 和 SHA-256 文件；系统菜单只显示 Polaris 图标。可在 Polaris 启动图标的右键操作中选择“检查更新”，也可运行 `polaris --updates`。Linux 分发包启动后会在后台检查正式 GitHub Release，发现新版本时显示更新窗口；失败时可手动重试。

更新窗口下载当前架构的 deb，校验 GitHub 提供的 SHA-256 与文件大小后才允许打开系统安装器。安装需要系统授权；完成后退出并重新启动 Polaris。没有关联 deb 安装器时，窗口提供 `sudo apt install` 命令。用户数据仍保存在 `~/.local/share/polaris-platform`（或 `$XDG_DATA_HOME/polaris-platform`），覆盖安装保留这些数据。

发布更新时，提升 `next/polaris_platform/metadata.py` 的版本，重新构建，并在本项目 GitHub 中发布同名正式标签（如 `v0.1.0.2`）。将 `polaris_0.1.0.2_amd64.deb` 和对应 `.sha256` 上传为 Release 资源；arm64 需在 arm64 环境单独构建。更新器读取 GitHub Release API 的资源 `digest`，缺少校验值或匹配架构资源时会明确报错。预发布和草稿不会作为更新。

冻结包中组件命令的 `{python}` 使用随包解释器，提供 Python 标准库基线（不含 Tk/IDLE 和标准库测试资源）及平台 Qt/SDK；第三方依赖须由插件自行提供。需要额外依赖的插件应在自己的环境安装依赖，并在组件命令中指定该环境的解释器。

## 插件源

主仓库的 [next/components](next/components) 按组件分别维护运行管理、协作、授权、窗口承载、画布、桌宠、插件源、组件管理和 Polaris Agent 的清单、实现与资源，随应用分发。其它 Git 或本地插件源可在组件管理中添加，再选择插件安装。仓库根目录使用 `polaris-source.json` 列出插件目录，每个插件维护自己的 `manifest.json`。标准见 [插件源契约](next/CONTRACT.md)。

[微信](https://github.com/gonerain/Polaris-weixin)、[日程](https://github.com/gonerain/Polaris-schedule)、[Agent Bridge](https://github.com/gonerain/Polaris-agent) 独立维护和发布。Codex/Pi 接入由 Agent Bridge 提供。随包的 [Polaris Agent](next/components/assistant/README.md) 提供模型对话与工具调用，可在画布独立使用，也可为微信自动回复。插件依赖由各插件维护。

## 组件设计原则

组件分工、能力调用和故障恢复见[架构说明](docs/component-platform-design.md)。以下是 Polaris 的组件设计约束与演进方向。

- **能力归组件所有。** 每个组件负责自身功能、数据、规则和状态，通过公开能力接口协作。使用接口承诺的返回字段属于正常依赖；组件不依赖对方内部实现。
- **能力与展示分开。** 画布本身也是组件，负责呈现与组织。组件可以没有视图，隐藏视图与停止能力是不同操作。
- **协作有明确负责人。** 发起协作的一方负责本次过程的组织、失败处理和结果汇报；各参与组件负责履行自身接口承诺、反馈结果与错误。共同底座提供共同机制，具体业务规则归所属组件维护。
- **依赖与退出行为明确。** 区分可选与必需依赖：可选依赖缺失时只减少相关功能，必需依赖缺失时明确报告相关能力不可用。允许组件动态加入和退出，并明确依赖变化后的行为。
- **能力自动发现，使用范围明确授权。** 能力及权限选项随组件加入、退出而更新，新增能力不自动获得授权。授权来源与范围在调用链中保持明确，不因调用另一个组件而获得它的全部权限。

判断边界是否合理，可以问：

- 对方保持接口契约、更换内部实现时，本组件是否仍需修改？
- 对方退出后，本组件还能做什么？
- 新增组件是否迫使许多旧组件修改？
- 同一业务规则是否由所属组件统一解释和维护？

必要的跨边界输入校验仍可保留，业务含义以所属组件为准。
这些原则借鉴 [KDE Plasma](https://api.kde.org/plasma-containment.html)、[OSGi](https://www.osgi.org/resources/architecture/)
和 [Home Assistant](https://contributors.home-assistant.io/architecture/core/) 的组件与协作思想。

## 版本与许可

软件版本为 **v0.1.0.2**；组件清单版本和协议版本独立维护。[更新记录](CHANGELOG.md)。

代码采用 [MIT](LICENSE)。默认美术素材来自 [PC2005-cloud/dsh-pet](https://github.com/PC2005-cloud/dsh-pet)，角色原型作者为上善无形，女仆鲸鱼娘设计为 ZipZipPipe，并非 DeepSeek 官方形象。素材遵守 **CC BY-NC-SA 4.0：署名、非商业、相同方式共享**；代码与美术素材分别适用各自许可。完整署名、来源和许可随包保留于 [默认皮肤目录](next/components/pet/skins/dshpet/ATTRIBUTION.md)。
